﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaExercicios01_if
{
    public partial class Ex11 : Form
    {
        public Ex11()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            float vlr = float.Parse(txtPreco.Text);
            char pg = char.Parse(txtPg.Text);
            float vlrt;

            switch (pg)
            {
                case '1':  vlrt = vlr * 0.9f;
                           lblResult.Text = vlrt.ToString("C"); break;
                case '2':  vlrt = vlr * 0.85f;
                           lblResult.Text = vlrt.ToString("C"); break;
                case '3':  vlrt = vlr;
                           lblResult.Text = vlrt.ToString("C"); break;
                case '4':  vlrt = vlr * 1.1f;
                           lblResult.Text = vlrt.ToString("C"); break;
                default: lblResult.Text = "Verifique o numero na tabela acima"; break;
            }
        }
    }
}
