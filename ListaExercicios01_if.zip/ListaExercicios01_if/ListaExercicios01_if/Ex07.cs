﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaExercicios01_if
{
    public partial class Ex07 : Form
    {
        public Ex07()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            float alt = float.Parse(txtAltura.Text);
            string sex = txtSexo.Text;

            if (sex == "m")
            {
                lblResult.Text = ("Peso ideal " + (72.7f * alt - 58));
            }
            else if (sex == "f")
            {
                lblResult.Text = ("Peso ideal " + (62.1f * alt - 44.7f));
            }
            else 
            {
                lblResult.Text = "Digite m OU f para o sexo";
            }
        }

        private void txtSexo_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblResult_Click(object sender, EventArgs e)
        {

        }

        private void lblSexo_Click(object sender, EventArgs e)
        {

        }
    }
}