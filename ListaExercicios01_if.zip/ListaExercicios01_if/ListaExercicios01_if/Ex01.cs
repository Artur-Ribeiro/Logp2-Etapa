﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaExercicios01_if
{
    public partial class Ex01 : Form
    {
        public Ex01()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            float valor1 = float.Parse(txtValor1.Text);
            float valor2 = float.Parse(txtValor2.Text);

            if (valor1 > valor2)
            {
                lblResult.Text = ("valor 1 é maior que o valor 2");
            }
            else if (valor1 < valor2)
            {
                lblResult.Text = ("valor 2 é maior que o valor 1");
            }
            else
            {
                lblResult.Text = ("valores iguais");
            }
        }
    }
}
