﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaExercicios01_if
{
    public partial class Ex02 : Form
    {
        public Ex02()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int nasc = int.Parse(txtNasc.Text);
            int ano = int.Parse(txtAno.Text);
            int idade = ano - nasc;

            if (idade >= 16)
            {
                lblResult.Text = "Pode Votar";
            }
            else if (idade < 16 && idade > 0)
            {
                lblResult.Text = "Não pode votar";
            }
            else
            {
                lblResult.Text = "Idade invalida";
            }
        }
    }
}
