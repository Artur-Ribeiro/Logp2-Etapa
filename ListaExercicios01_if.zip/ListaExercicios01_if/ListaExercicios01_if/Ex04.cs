﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaExercicios01_if
{
    public partial class Ex04 : Form
    {
        public Ex04()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int maca = int.Parse(txtMacas.Text);
            float result;

            if (maca >= 12)
            {
                result = maca * 0.30f;
                lblResult.Text = "Valor total: " + result.ToString("C");
            }
            else if (maca < 12 && maca > 0)
            {
                result = maca * 0.25f;
                lblResult.Text = "Valor total: " + result.ToString("C");
            }
            else
            {
                lblResult.Text = "Valor invalido";
            }
        }
    }
}
