﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaExercicios01_if
{
    public partial class Ex05 : Form
    {
        public Ex05()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            float vlrlanche = float.Parse(txtVlrlanche.Text);
            float vlrpg = float.Parse(txtVlrpg.Text);
            float total = vlrpg - vlrlanche;

            if (total < 0)
            {
                lblResult.Text = "Não é possivel comprar";
            }
            else if (total == 0)
            {
                lblResult.Text = "Troco não necessário";
            }
            else
            {
                lblResult.Text = "Troco igual a: " + total.ToString("C");
            }
        }
    }
}
