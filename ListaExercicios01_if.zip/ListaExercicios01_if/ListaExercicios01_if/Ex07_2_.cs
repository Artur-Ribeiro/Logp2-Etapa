﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaExercicios01_if
{
    public partial class Ex07_2_ : Form
    {
        public Ex07_2_()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            float alt = float.Parse(txtAltura.Text);
            char sex = char.Parse(txtSexo.Text);

            switch (sex)
            {
                case 'm': lblResult.Text = ("Peso ideal " + (72.7f * alt - 58)); break;

                case 'f': lblResult.Text = ("Peso ideal " + (62.1f * alt - 44.7f)); break;

                default: lblResult.Text = "Digite m OU f para o sexo"; break;
            }
        }
    }
}
