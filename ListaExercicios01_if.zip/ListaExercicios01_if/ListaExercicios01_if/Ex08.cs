﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaExercicios01_if
{
    public partial class Ex08 : Form
    {
        public Ex08()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            string sex = txtSexo.Text;

            if (sex == "f")
            {
                lblResult.Text = "Pode se candidatar a vaga";
            }
            else if (sex == "m")
            {
                lblResult.Text = "Não pode se candidatar a vaga";
            }
            else
            {
                lblResult.Text = "Digite m OU f para o sexo";
            }
        }
    }
}
