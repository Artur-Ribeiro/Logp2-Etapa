﻿namespace ListaExercicios01_if
{
    partial class Ex05
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl1 = new System.Windows.Forms.Panel();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblVlrlanche = new System.Windows.Forms.Label();
            this.lblResult = new System.Windows.Forms.Label();
            this.txtVlrlanche = new System.Windows.Forms.TextBox();
            this.txtVlrpg = new System.Windows.Forms.TextBox();
            this.lblVlrpg = new System.Windows.Forms.Label();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.pnl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl1
            // 
            this.pnl1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.pnl1.Controls.Add(this.lblTitulo);
            this.pnl1.Location = new System.Drawing.Point(0, -4);
            this.pnl1.Name = "pnl1";
            this.pnl1.Size = new System.Drawing.Size(282, 65);
            this.pnl1.TabIndex = 1;
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(33, 11);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(222, 42);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Exercicio 05";
            // 
            // lblVlrlanche
            // 
            this.lblVlrlanche.AutoSize = true;
            this.lblVlrlanche.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVlrlanche.Location = new System.Drawing.Point(12, 77);
            this.lblVlrlanche.Name = "lblVlrlanche";
            this.lblVlrlanche.Size = new System.Drawing.Size(148, 24);
            this.lblVlrlanche.TabIndex = 2;
            this.lblVlrlanche.Text = "Valor do lanche:";
            // 
            // lblResult
            // 
            this.lblResult.AutoSize = true;
            this.lblResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResult.Location = new System.Drawing.Point(12, 276);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(16, 24);
            this.lblResult.TabIndex = 3;
            this.lblResult.Text = "-";
            // 
            // txtVlrlanche
            // 
            this.txtVlrlanche.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVlrlanche.Location = new System.Drawing.Point(16, 120);
            this.txtVlrlanche.Name = "txtVlrlanche";
            this.txtVlrlanche.Size = new System.Drawing.Size(144, 29);
            this.txtVlrlanche.TabIndex = 4;
            // 
            // txtVlrpg
            // 
            this.txtVlrpg.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVlrpg.Location = new System.Drawing.Point(16, 225);
            this.txtVlrpg.Name = "txtVlrpg";
            this.txtVlrpg.Size = new System.Drawing.Size(144, 29);
            this.txtVlrpg.TabIndex = 6;
            // 
            // lblVlrpg
            // 
            this.lblVlrpg.AutoSize = true;
            this.lblVlrpg.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVlrpg.Location = new System.Drawing.Point(12, 182);
            this.lblVlrpg.Name = "lblVlrpg";
            this.lblVlrpg.Size = new System.Drawing.Size(107, 24);
            this.lblVlrpg.TabIndex = 5;
            this.lblVlrpg.Text = "Valor pago:";
            // 
            // btnCalcular
            // 
            this.btnCalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.Location = new System.Drawing.Point(16, 328);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(144, 35);
            this.btnCalcular.TabIndex = 7;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // Ex05
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(281, 386);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtVlrpg);
            this.Controls.Add(this.lblVlrpg);
            this.Controls.Add(this.txtVlrlanche);
            this.Controls.Add(this.lblResult);
            this.Controls.Add(this.lblVlrlanche);
            this.Controls.Add(this.pnl1);
            this.Name = "Ex05";
            this.Text = "Ex05";
            this.pnl1.ResumeLayout(false);
            this.pnl1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnl1;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblVlrlanche;
        private System.Windows.Forms.Label lblResult;
        private System.Windows.Forms.TextBox txtVlrlanche;
        private System.Windows.Forms.TextBox txtVlrpg;
        private System.Windows.Forms.Label lblVlrpg;
        private System.Windows.Forms.Button btnCalcular;
    }
}