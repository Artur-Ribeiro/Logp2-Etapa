﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaExercicios01_if
{
    public partial class Ex06 : Form
    {
        public Ex06()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int lados = int.Parse(txtLado.Text);

            if (lados <= 0)
            {
                lblResult.Text = "Valor inválido";
            }
            else if (lados == 1)
            {
                lblResult.Text = "Valor inválido";
            }
            else if (lados == 3)
            {
                lblResult.Text = "Triângulo";
            }
            else if (lados == 4)
            {
                lblResult.Text = "Quadrado";
            }
            else
            {
                lblResult.Text = ("Polígono com " + lados + "lados");
            }
        }
    }
}
