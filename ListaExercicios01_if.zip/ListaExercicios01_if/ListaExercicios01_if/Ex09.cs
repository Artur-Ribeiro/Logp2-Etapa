﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaExercicios01_if
{
    public partial class Ex09 : Form
    {
        public Ex09()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            float num = float.Parse(txtNum.Text);

            if (num > 0)
            {
                lblResult.Text = ("Número positivo");
            }
            else if (num < 0)
            {
                lblResult.Text = ("Número negativo");
            }
            else
            {
                lblResult.Text = ("Número neutro ou positivo");
            }
        }
    }
}
