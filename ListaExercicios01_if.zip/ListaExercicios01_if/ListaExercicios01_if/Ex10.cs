﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaExercicios01_if
{
    public partial class Ex10 : Form
    {
        public Ex10()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            float peso = float.Parse(txtPeso.Text);
            float alt = float.Parse(txtAltura.Text);
            float imc;

            imc = peso / (alt*alt);

            if (imc < 18.5f)
            {
                lblResult.Text = ("Abaixo do peso");
            }
            else if (imc <= 25)
            {
                lblResult.Text = ("Peso normal");
            }
            else if (imc <= 30)
            {
                lblResult.Text = ("Acima do peso");
            }
            else
            {
                lblResult.Text = ("Obeso");
            }
        }
    }
}
