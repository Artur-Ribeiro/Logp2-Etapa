﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaExercicios01_if
{
    public partial class Ex08_2_ : Form
    {
        public Ex08_2_()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            char sex = char.Parse(txtSexo.Text);

            switch (sex)
            {
                case 'f': lblResult.Text = "Pode se candidatar a vaga"; break;

                case 'm': lblResult.Text = "Não pode se candidatar a vaga"; break;

                default: lblResult.Text = "Digite m OU f para o sexo"; break;
            }
        }

    }
}