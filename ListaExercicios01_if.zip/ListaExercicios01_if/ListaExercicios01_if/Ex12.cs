﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListaExercicios01_if
{
    public partial class Ex12 : Form
    {
        public Ex12()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int naluno = int.Parse(txtNum.Text);
            float n1 = float.Parse(txtN1.Text);
            float n2 = float.Parse(txtN2.Text);
            float n3 = float.Parse(txtN3.Text);
            float n4 = float.Parse(txtN4.Text);
            float media = (n1 + n2 + n3 + n4)/4;
            float total = (n1 + n2 + n3 + n4);

            if (total >= 90)
            {
                lblResult.Text = ("Aluno: " + naluno + " Media: " + media + " Nota final A");
            }
            else if (total >= 75)
            {
                lblResult.Text = ("Aluno: " + naluno + " Media: " + media + " Nota final B");
            }
            else if (total >= 60)
            {
                lblResult.Text = ("Aluno: " + naluno + " Media: " + media + " Nota final C");
            }
            else if (total >= 40)
            {
                lblResult.Text = ("Aluno: " + naluno + " Media: " + media + " Nota final D");
            }
            else
            {
                lblResult.Text = ("Aluno: " + naluno + " Media: " + media + " Nota final E");
            }
        }
    }
}
